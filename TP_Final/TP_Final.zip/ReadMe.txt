Bonjour à toi au correcteur d'un jour.

Ma seconde fonctionnalité pour ce TP de statistique sur les mots d'un dictionnaire... est un jeu !

Le second paramètre a entrer est un peudo ou nom de joueur. On peut mettre n'importe quoi.

Le jeu proposé est un simple pendu !

Au début de la partie le script va chercher aléatoirement un mot dans le dico fournit en paramètre 1.
ATTENTION si vous utilisez un dico maison, il faut que les mots soient en majuscule, un seul mot par ligne
et un retour à la ligne à chaque fin de ligne, sans espace. On oublie aussi les accents et caractères non alphabétiques.

Bon jeu !